// assets/js/main.js
// contoh: validasi form sederhana
